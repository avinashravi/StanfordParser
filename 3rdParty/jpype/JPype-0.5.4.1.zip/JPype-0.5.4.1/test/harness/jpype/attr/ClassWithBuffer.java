package jpype.attr;

import java.awt.image.BufferStrategy;

public class ClassWithBuffer
{
  public BufferStrategy bufferStrategy;

  public void foo() {
      System.out.println("foo");
  }
}
